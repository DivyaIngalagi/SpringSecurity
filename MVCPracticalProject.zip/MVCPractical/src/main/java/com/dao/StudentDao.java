package com.dao;

import java.util.List;



public interface StudentDao {


	
	public void GiveExam();
	
	
	
}
